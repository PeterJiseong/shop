package com.shop.entity;

import com.shop.constant.ItemSellStatus;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;

//@Entity : 클래스를 entity로 설정
//@Table : 엔티티와 매필할 테이블 설정
@Entity
@Table(name="item")
@Getter
@Setter
@ToString
public class Item {
    @Id
    @Column(name="item_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;//상품코드

    @Column(nullable=false, length = 50)
    private String itemName;//상품명

    @Column(name = "price", nullable = false)
    private int price;//가격

    @Column(nullable = false)
    private int stockNumber;//재고수량

    //@Lob : BLOB, CLOB 타입 매핑
    //BLOB, CLOB : 사이즈가 큰 데이터를 외부 파일로 저장하기 위한 데이터 타입
    @Lob
    @Column(nullable = false)
    private String itemDetail;//상품설명

    @Enumerated(EnumType.STRING)
    private ItemSellStatus itemSellStatus;//상품판매상태


    private LocalDateTime regTime;//등록시간
    private LocalDateTime updateTime;//제품 수정 시간

}
